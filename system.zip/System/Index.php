<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System</title>
    <link rel="stylesheet" href="style.css">.


</head>

<body>


    <div class="sidebar">
        <div class="left_img_cont">
            <img src="images/right.png" alt="left-side image" id="left-image">

        </div>
        <div class="navs">
            <li>MY PROFILE <img src="images/smile_men.png" alt=""></li>
            <li class="chapter-rules">CHAPTER RULES & REGULATIONS BY LAWS <img src="images/smile_men.png" alt=""></li>
            <li>5 PILLARS<img src="images/smile_men.png" alt=""></li>
            <li>13 DOCTRINES <img src="images/smile_men.png" alt=""></li>
            <li>FOUNDING AND FATHERS<img src="images/smile_men.png" alt=""></li>
            <li>ACTIVITIES AND EVENTS<img src="images/smile_men.png" alt=""></li>
            <li>TEAMS <img src="images/smile_men.png" alt=""></li>
            <li>SERVICES <img src="images/smile_men.png" alt=""></li>
            <li>SERVICES <img src="images/smile_men.png" alt=""></li>
            
        </div>
        
    </div>
    <div class="content">
        <div class="header">
            <h1>ALPHA KAPPA RHO</h1>
            <p>INTERNATIONAL HUMANITARY SERVICE FRATERNITY AND SORORITY</p>
            <h3>Zamboanga City Council</h3>
        </div>
        <img src="images/front-removebg-preview.png" alt="right-side image" id="right-image">

    </div>


</body>

</html>